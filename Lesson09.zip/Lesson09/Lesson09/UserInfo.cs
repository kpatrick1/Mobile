﻿using System;
namespace Lesson09
{
    public class UserInfo
    {

        public string UserName { get; set; }

    }
}
