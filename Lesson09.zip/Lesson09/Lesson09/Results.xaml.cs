﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Lesson09
{
    public partial class Results : ContentPage
    {
        public Results()
        {
            InitializeComponent();
        }
    }
}
